  vCardBlaster

Copyright (C) 2009 Shadow Cave LLC

Written 2009 by JP Dunning (.ronin)
ronin@shadowcave.org
<www.hackfromacave.com>
 
  License

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License version 2 as
published by the Free Software Foundation;

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS.
IN NO EVENT SHALL THE COPYRIGHT HOLDER(S) AND AUTHOR(S) BE LIABLE FOR ANY 
CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES 
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION
OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN 
CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

ALL LIABILITY, INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PATENTS, 
COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS, RELATING TO USE OF THIS SOFTWARE IS 
DISCLAIMED.


  About

vCardBlaster is a tool designed to abuse the sending of vCards over Bluetooth. It allows the user to send a continual stream of vCards to attempt a Bluetooth DoS or abuse other device recourses. A user can send a specific vCard or allow vCardBalster to send a new generated vCard for each iteration. It also allows for an attack on one or all Bluetooth enabled devices in the area.


  Install

To install vCardBlaster run "make" from the vCardBlaster directory or type "gcc vcardblaster.c -o vcb -lbluetooth".  


  Help

NAME
   vCardBlaster

SYNOPSIS
   vcblaster [-t times] [options] [vcard] [target]

DESCRIPTION
   [btaddr]             Address of the target device.  Format: XX:XX:XX:XX:XX:XX
   -a                   Send vCard to all devices in range
   -g                   Generate random vCard
   -h                   Help
   -t [times]           Number of times to send vCard. Default: 10
   -v [vcard]           Specify vcard location


  Usage

Find devices:
   > hcitool scan

Change the device name with:
   > hciconfig hci0 name "new name"


Attack a specific device with a specific vCard twenty times:
   > vcblaster -v MyvCard -t 20 00:11:22:33:44:55

Attack on all device in range with generated vCards:
   > vcblaster -g -t 20 -a
