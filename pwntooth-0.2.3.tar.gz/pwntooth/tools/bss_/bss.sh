#!/bin/bash

i=0
n=10000
divadd=001237b68d7a


echo -n "What is the device address? "
read -e divadd

./bss -s 100 -m 12 -M 0 $divadd 


























